package Exercise_1;

public class Whilepro 
{

public static void main(String [] args)
{
	boolean a = true;
	while(a)
	{
		System.out.println("Hello Bhavesh");
	}
	System.out.println("Bye Bhavesh");

}
}
